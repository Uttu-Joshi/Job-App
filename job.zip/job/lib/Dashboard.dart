import 'package:flutter/material.dart';
import 'package:job/main.dart';
import 'Screens/Home.dart';
import 'Screens/Applications.dart';
import 'Screens/Profile.dart';
import 'Screens/More.dart';
import 'Screens/opptunities.dart';
class DashBoard extends StatefulWidget {
  const DashBoard({Key? key}) : super(key: key);

  @override
  State<DashBoard> createState() => _DashBoardState();
}

class _DashBoardState extends State<DashBoard> {
  int _currentindex = 0;
  final List _children = [Jobs(),Applications(),Profile(),Oppturnities(),MyHomePage()];

  void onTappedBar(int index){
    setState(() {
      _currentindex = index;
    });
  }
  @override
  Widget build(BuildContext context) {
    return Scaffold( backgroundColor: Colors.grey[100],
      body: _children[_currentindex],
      bottomNavigationBar: BottomNavigationBar(
        onTap: onTappedBar,
        currentIndex: _currentindex,
        items: [
          BottomNavigationBarItem(icon: Icon(Icons.home),label:'Home',backgroundColor: Colors.amber ),
          BottomNavigationBarItem(icon: Icon(Icons.developer_board),label:'Applications',backgroundColor: Colors.amber ),
          BottomNavigationBarItem(icon: Icon(Icons.person),label: 'profile',backgroundColor: Colors.amber ),
          BottomNavigationBarItem(icon: Icon(Icons.card_giftcard_outlined),label: 'oppturnities',backgroundColor: Colors.amber ),
          BottomNavigationBarItem(icon: Icon(Icons.more_horiz,color: Colors.white,),label: 'More',backgroundColor: Colors.amber ),
        ],
      ),
    );
  }
}
