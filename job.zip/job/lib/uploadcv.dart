import 'package:flutter/material.dart';
import 'dart:io';
import 'package:path/path.dart';
import 'package:dio/dio.dart';
import 'package:file_picker/file_picker.dart';

class UploadCv extends StatefulWidget {
  const UploadCv({Key? key}) : super(key: key);

  @override
  State<UploadCv> createState() => _UploadCvState();
}

class _UploadCvState extends State<UploadCv> {

  late File _file;

  Future getFile()async{
    FilePickerResult? result = await FilePicker.platform.pickFiles(
      type: FileType.custom,
      allowedExtensions: ['jpg', 'pdf', 'doc'],
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        body: SingleChildScrollView(
          child: Padding(padding: EdgeInsets.all(20),
            child: Column(
              children: [
                SizedBox(height: 40,),
            Padding(
              padding: EdgeInsets.all(100),
              child: new MaterialButton(
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.all(Radius.circular(20.0))),
                elevation: 5.0,
                minWidth: 200.0,
                height: 35,
                color: Colors.amber,
                child: new Text('Upload',
                    style: new TextStyle(fontSize: 16.0, color: Colors.white)),
                onPressed: () {

                },
              ),
            ),
                Expanded(child: Column(
                  children: [

                  ],
                )),
                SizedBox(height: 40,),
                Padding(
                  padding: EdgeInsets.all(100),
                  child: new MaterialButton(
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.all(Radius.circular(20.0))),
                    elevation: 5.0,
                    minWidth: 200.0,
                    height: 35,
                    color: Colors.amber,
                    child: new Text('Save',
                        style: new TextStyle(fontSize: 16.0, color: Colors.white)),
                    onPressed: () {

                    },
                  ),
                ),
              ]
          ),
        ),
    ));
  }
}
