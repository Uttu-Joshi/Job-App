import 'package:flutter/material.dart';
import 'textField/appTextField.dart';
import 'main.dart';
class ResetPass extends StatelessWidget {
  const ResetPass({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: ListView(
        padding: EdgeInsets.symmetric(horizontal: 20),
        children: [
          SizedBox(height: 60,),
          Image(image: AssetImage('images/re.png'),height: 300,),
          SizedBox(height: 20,),
          Text('Reset Password',style: TextStyle(color: Colors.amber,fontSize: 20,fontWeight: FontWeight.bold),textAlign: TextAlign.center,),
          SizedBox(height: 40,),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 40),
            child: AppTextField(icon: Icons.key, hint: "Enter new Password", helpOnTap: () {  }, helpText: '',),
          ),
          SizedBox(height: 20,),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 40),
            child: AppTextField(icon: Icons.lock, hint: "Confirm Password", helpText: '', helpOnTap: () {},),
          ),
          SizedBox(height: 40,),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 120),
            child: MaterialButton( color: Colors.amber,padding: EdgeInsets.all(10),
                onPressed: (){Navigator.push(context, MaterialPageRoute(builder: (context)=> Home()));},
                child: Text('Reset',style: TextStyle(color: Colors.brown,fontWeight: FontWeight.bold,fontSize: 20,),),
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.all(Radius.circular(16)),),),
          )
        ],
      ),
    );
  }
}
