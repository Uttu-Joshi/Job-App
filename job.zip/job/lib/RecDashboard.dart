import 'package:flutter/material.dart';
import 'DashBoardPage.dart';

class RecDashboard extends StatefulWidget {
  const RecDashboard({Key? key}) : super(key: key);

  @override
  State<RecDashboard> createState() => _RecDashboardState();
}

class _RecDashboardState extends State<RecDashboard> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: MakeDashboardItems(),
    );
  }
}
