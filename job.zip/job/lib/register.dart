import 'dart:convert';
import 'main.dart';
import 'package:flutter/material.dart';
import 'package:http/http.dart';
import 'package:http/http.dart';

var session = "";

class Register extends StatefulWidget {
  const Register({Key? key}) : super(key: key);

  @override
  State<Register> createState() => _RegisterState();
}

class _RegisterState extends State<Register> {
  TextEditingController email = new TextEditingController();

  String msg = "";

  void SignUp(String email) async {
    var session_temp = '';
    try{
      Response response = await post(
          Uri.parse('https://ewiz.gq/android/vendor_registration.php'),
          body: {
            'set_email_mobile' : email,
          }
      );
      if(response.statusCode == 200){

        var data = jsonDecode(response.body.toString());
        print(data['SESSION_ID']);
        print('Login successfully');
        session_temp = data['SESSION_ID'];
        Navigator.pushReplacementNamed(context, '/SignUpPage');
      }else {
        print('failed');
      }
    }catch(e){
      print(e.toString());
    }
    session = session_temp;
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: ListView(
          children: [
            Stack(children: [ Align(alignment: Alignment.center,),
              IconButton(onPressed: (){Navigator.pop(context);}, icon: Icon(Icons.arrow_back,color: Colors.black,),),
              Image(image: AssetImage('images/su.png'),height: 250,)]),
            SizedBox(height: 20,),
            Text('Welcome Please enter your email or mobile number to proceed',style: TextStyle(color: Colors.amber,fontSize: 20,fontWeight: FontWeight.w400),textAlign: TextAlign.center,),
            SizedBox(height: 20,),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 40),
              child: TextField(
                controller: email,
                decoration: InputDecoration(hintText: 'Email or mobile number',hintStyle: TextStyle(color: Colors.black38),prefixIcon: Icon(Icons.key),
                enabledBorder: UnderlineInputBorder(borderSide: BorderSide(color: Colors.black38))),
              ),
            ),
            SizedBox(height: 30,),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 120),
              child: MaterialButton( color: Colors.amber,padding: EdgeInsets.all(16), minWidth: 40,
                onPressed: (){
                        SignUp(email.text.toString());
                }, child: Text('Submit',style: TextStyle(fontSize: 20,color: Colors.brown,fontWeight: FontWeight.bold),),
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.all(Radius.circular(20)),),),
            ),
          ],
        ),
      ),
    );
  }
}
