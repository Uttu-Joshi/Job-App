import 'dart:convert';
import 'package:http/http.dart' as http;
import 'package:flutter/material.dart';
import 'package:http/http.dart';
import 'register.dart';
class OtpScreen extends StatefulWidget {
  const OtpScreen({Key? key}) : super(key: key);

  @override
  State<OtpScreen> createState() => _OtpScreenState();
}

class _OtpScreenState extends State<OtpScreen> {
  TextEditingController verification_code = new TextEditingController();

  String msg = '';

  void verify(String verify) async {
    print(session);
    try{
      Response response = await post(
          Uri.parse('https://ewiz.gq/android/vendor_registration.php'),
          body: {
           'SESSION_ID':session.toString(),
            'verifyOtp': verify
          }
      );
      if(response.statusCode == 200){
        Navigator.pushReplacementNamed(context, '/ProfilePage');
        var userdata = jsonDecode(response.body.toString());
        if(userdata['SUCCESS'] == "OTP VERIFIED"){
          Navigator.pushReplacementNamed(context, '/SignUpPage');
        }else if(userdata['ERROR'] == "INVALID OTP"){

        }
        print(userdata["ERROR"]);
        print(userdata["SUCCESS"]);
      }
    }catch(e){
      print(e.toString());
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Padding(
        padding: EdgeInsets.all(16),
        child: ListView(
          children: [
            SizedBox(height: 45,),
            Text('Please enter the otp sent at your email...',style: TextStyle(color: Colors.amber,fontSize: 20,fontWeight: FontWeight.w400),textAlign: TextAlign.center,),
            SizedBox(height: 20,),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 40),
              child: Stack(
                  children:[ TextField(
                    controller: verification_code,
                    decoration: InputDecoration(hintText: 'otp...',hintStyle: TextStyle(color: Colors.black38),prefixIcon: Icon(Icons.edit),
                        enabledBorder: UnderlineInputBorder(borderSide: BorderSide(color: Colors.black38))),
                  ),],
              ),
            ),
            SizedBox(height: 30,),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 120),
              child: MaterialButton( color: Colors.amber,padding: EdgeInsets.all(16), minWidth: 40,
                onPressed: (){verify(verification_code.text.toString());}, child: Text('Submit',style: TextStyle(fontSize: 20,color: Colors.brown,fontWeight: FontWeight.bold),),
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.all(Radius.circular(20)),),),
            ),
          ],
        ),
      ),
    );
  }
}
