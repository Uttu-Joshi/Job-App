import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:job/main.dart';
import 'package:job/textField/onlineButton.dart';
import 'package:http/http.dart' as http;

class SetPassword extends StatefulWidget {
  const SetPassword({Key? key}) : super(key: key);

  @override
  State<SetPassword> createState() => _SetPasswordState();
}

class _SetPasswordState extends State<SetPassword> {
  TextEditingController email = new TextEditingController();
  TextEditingController password = new TextEditingController();

  String msg = '';

  Future register() async{
    var url = "http://192.168.1.7/job/loginconn.php";
    //var url = "https://otp-gen.000webhostapp.com/loginconn.php";
    // var url = "http://192.168.1.21/job/login.php";
    final response = await http.post(Uri.parse(url),body: {
      "email":email.text, "password": password.text
    });
    var data = json.decode(response.body);
    if(data.length == 0){
      setState(() {
        msg = "Error: Please enter a vaild otp";
      });
    }else{
      Navigator.pushReplacementNamed(context, '/DashBoard');
      print("Connection Established");
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      body: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 24),
        child: ListView(
          children: [
            Image(image: AssetImage('images/log.png'),height: 250,),
            SizedBox(height: 20,),
            Text('Create Account',style: TextStyle(color: Colors.amber,fontSize: 20,fontWeight: FontWeight.bold),textAlign: TextAlign.center,),
            SizedBox(height: 20,),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 40),
              child: TextField(
                //controller: email,
                decoration: InputDecoration(hintText: 'Email',hintStyle: TextStyle(color: Colors.black38),
                    prefixIcon: Icon(Icons.email),enabledBorder: UnderlineInputBorder(borderSide: BorderSide(color: Colors.black38))),
              ),
            ),
            SizedBox(height: 20,),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 40),
              child: Stack(
                  children:[ TextField(
                    // controller: password,
                    decoration: InputDecoration(hintText: 'Enter Password',hintStyle: TextStyle(color: Colors.black38),prefixIcon: Icon(Icons.lock),
                        enabledBorder: UnderlineInputBorder(borderSide: BorderSide(color: Colors.black38))),
                  ),

                  ]
              ),
            ),
            SizedBox(height: 45,),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 100),
              child: MaterialButton( color: Colors.amber,padding: EdgeInsets.all(10),
                onPressed: (){
                  Navigator.push(context, MaterialPageRoute(builder: (context) => Home(),));
                  //  register();
                },
                child: Text('Create Account',style: TextStyle(fontSize: 20,color: Colors.brown,fontWeight: FontWeight.bold),),
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.all(Radius.circular(20)),),),
            ),

    ])
    ));
  }
}
