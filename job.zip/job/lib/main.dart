import 'dart:convert';
import 'package:flutter/gestures.dart';
import 'package:flutter/material.dart';
import 'package:job/Profile/ProfileScreen.dart';
import 'package:job/Profile/UserPreferences.dart';
import 'package:job/RecDashboard.dart';
import 'package:job/SignUpPage.dart';
import 'package:job/otpScreen.dart';
import 'package:job/password.dart';
import 'package:job/register.dart';
import 'package:job/DashBoardPage.dart';
import 'package:job/textField/appTextField.dart';
import 'package:job/textField/onlineButton.dart';
import 'Reset.dart';
import 'Dashboard.dart';
import 'Screens/Applications.dart';
import 'package:http/http.dart' as http;
import 'package:fluttertoast/fluttertoast.dart';
import 'package:shared_preferences/shared_preferences.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await UserPreferences.init();
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return MaterialApp( debugShowCheckedModeBanner: false,
     home: const Splash(),
      routes: <String,WidgetBuilder>{
        '/DashBoard': (BuildContext context) => new DashBoard(),
        '/Register':(BuildContext context) => new Register(),
        '/Home':(BuildContext context) => new Home(),
        '/SetPassword':(BuildContext context) => new SetPassword(),
        '/Otp':(BuildContext context) => new OtpScreen(),
        '/SignUpPage':(BuildContext context) => new SignUpPage(),
        '/ProfilePage':(BuildContext context) => new ProfilePage(),
      },
    );
  }
}

class Splash extends StatefulWidget {
  const Splash({Key? key}) : super(key: key);

  @override
  State<Splash> createState() => _SplashState();
}

class _SplashState extends State<Splash> {
  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    Future.delayed(const Duration(seconds: 3), (){
      Navigator.pushReplacement(context, MaterialPageRoute(builder: (context)=>const Register()));
    });
  }
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
              Image(image: AssetImage('images/company.png')),
          ],
        ),
      ),
    );
  }
}


class Home extends StatefulWidget {
  const Home({Key? key}) : super(key: key);

  @override
  State<Home> createState() => _HomeState();
}

class _HomeState extends State<Home> {
  TextEditingController email = new TextEditingController();
  TextEditingController password = new TextEditingController();
  TapGestureRecognizer registeronTap = TapGestureRecognizer();

  String msg = '';

  Future register() async{
   var url = "http://192.168.1.8/job/loginconn.php";
   //var url = "https://otp-gen.000webhostapp.com/loginconn.php";
   // var url = "http://192.168.1.21/job/login.php";
    final response = await http.post(Uri.parse(url),body: {
      "email" : email.text, "password":password.text, 
    });
    var userdata = json.decode(response.body);
    if(userdata.length == 0){
      setState(() {
        msg = "Login Fail";
      });
    }else{
      if(userdata[0]['status'] == "recruiter"){
        Navigator.push(context,MaterialPageRoute(builder: (context)=>DashBoard()));
      } else{
      Navigator.pushReplacementNamed(context, '/DashBoard');
      print("Connection Established");}
    }
  }

  @override
  void initState() {
    // TODO: implement initState
    registeronTap = TapGestureRecognizer();
    registeronTap..onTap = () {
      Navigator.push(context, MaterialPageRoute(builder: (_)=>Register()),);
    };
    super.initState();
  }
  @override
  Widget build(BuildContext context) {
    return Scaffold(backgroundColor: Colors.white,
      body: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 24),
        child: ListView(
          children: [
            Image(image: AssetImage('images/log.png'),height: 250,),
            SizedBox(height: 20,),
            Text('Login',style: TextStyle(color: Colors.amber,fontSize: 20,fontWeight: FontWeight.bold),textAlign: TextAlign.center,),
            SizedBox(height: 20,),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 40),
              child: TextField(
                controller: email,
                decoration: InputDecoration(hintText: 'Email',hintStyle: TextStyle(color: Colors.black38),
                prefixIcon: Icon(Icons.email),enabledBorder: UnderlineInputBorder(borderSide: BorderSide(color: Colors.black38))),
              ),
            ),
            SizedBox(height: 20,),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 40),
              child: Stack(
                children:[ TextField(
                  controller: password,
                  decoration: InputDecoration(hintText: 'password',hintStyle: TextStyle(color: Colors.black38),prefixIcon: Icon(Icons.lock),
                  enabledBorder: UnderlineInputBorder(borderSide: BorderSide(color: Colors.black38))),
                ),
                  Container( height: 48,
                    child: Align( alignment: Alignment.centerRight,
                      child: GestureDetector(
                        onTap: (){
                          Navigator.push(context, MaterialPageRoute(builder: (context)=>ResetPass(),));
                        },
                        child: Text('Forgot?',style: TextStyle(color: Colors.blue),),
                      ),
                    ),
                  )
                ]
              ),
            ),
            SizedBox(height: 45,),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 120),
              child: MaterialButton( color: Colors.amber,padding: EdgeInsets.all(10),
                  onPressed: (){
                   // Navigator.push(context, MaterialPageRoute(builder: (context) => DashBoard(),));
                   register();
                },
                 child: Text('Login',style: TextStyle(fontSize: 20,color: Colors.brown,fontWeight: FontWeight.bold),),
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.all(Radius.circular(20)),),),
            ),
            SizedBox(height: 15,),
            Text('Or Login With...',style: TextStyle(color: Colors.black38),textAlign: TextAlign.center,),
            SizedBox(height: 20,),
            Row(
              children: [
                Expanded(child: OnlineButton('images/go.jpg', (){})),Expanded(child:OnlineButton('images/in.jpg', (){})),Expanded(child:OnlineButton('images/tw.png', (){}))
              ],
            ),
            SizedBox(height: 25,),
            Text.rich(TextSpan(text: "Don't have an account yet?",
            children:[ TextSpan(text: " SignUp",style: TextStyle(color: Colors.amber,fontWeight: FontWeight.bold,fontSize: 20),recognizer: registeronTap,
            ),]),textAlign: TextAlign.center,),
            SizedBox(height: 20,),
            Center(child: Text(msg,style: TextStyle(color: Colors.red),)),
          ],
        ),
      ),
    );
  }
}


