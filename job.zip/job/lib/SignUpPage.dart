import 'dart:convert';
import 'register.dart';
import 'package:flutter/material.dart';
import 'package:http/http.dart';
import 'package:job/otpScreen.dart';

class SignUpPage extends StatefulWidget {
  const SignUpPage({Key? key}) : super(key: key);

  @override
  State<SignUpPage> createState() => _SignUpPageState();
}

class _SignUpPageState extends State<SignUpPage> {
  TextEditingController email = new TextEditingController();
  TextEditingController mobile = new TextEditingController();
  TextEditingController name = new TextEditingController();
  TextEditingController vendor_type = new TextEditingController();

  String msg = '';
  String txt = 'register';

  void EnterDetails(String email,mobile,name,vendor_type) async {
    try{
      Response response = await post(
          Uri.parse('https://ewiz.gq/android/vendor_registration.php'),
          body: {
            'register':txt,
            'email' : email,
            'mobile':mobile,
            'name':name,
            'vendor_type':vendor_type
          }
      );
      if(response.statusCode == 200){
        var userdata = jsonDecode(response.body.toString());
        if(userdata.length == 0){
          setState(() {
            msg = userdata["KEY_NOT_SET"];
          });
        }else {

          Navigator.push(
              context, MaterialPageRoute(builder: (context) => OtpScreen()));
        }
      }
    }catch(e){
      print(e.toString());
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: ListView(
          children: [
            Stack(children: [ Align(alignment: Alignment.center,),
              IconButton(onPressed: (){Navigator.pop(context);}, icon: Icon(Icons.arrow_back,color: Colors.black,),),
              Image(image: AssetImage('images/su.png'),height: 250,)]),
            SizedBox(height: 20,),
            Text('Please Enter Following Details',style: TextStyle(color: Colors.amber,fontSize: 20,fontWeight: FontWeight.w400),textAlign: TextAlign.center,),
            SizedBox(height: 20,),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 40),
              child: TextField(
                controller: email,
                decoration: InputDecoration(hintText: 'Email',hintStyle: TextStyle(color: Colors.black38),prefixIcon: Icon(Icons.mail),
                    enabledBorder: UnderlineInputBorder(borderSide: BorderSide(color: Colors.black38))),
              ),
            ),
            SizedBox(height: 20,),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 40),
              child: TextField(
                controller: mobile,
                decoration: InputDecoration(hintText: 'mobile number',hintStyle: TextStyle(color: Colors.black38),prefixIcon: Icon(Icons.phone),
                    enabledBorder: UnderlineInputBorder(borderSide: BorderSide(color: Colors.black38))),
              ),
            ),
            SizedBox(height: 20,),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 40),
              child: TextField(
                controller: name,
                decoration: InputDecoration(hintText: 'name',hintStyle: TextStyle(color: Colors.black38),prefixIcon: Icon(Icons.person),
                    enabledBorder: UnderlineInputBorder(borderSide: BorderSide(color: Colors.black38))),
              ),
            ),
            SizedBox(height: 20,),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 40),
              child: TextField(
                controller: vendor_type,
                decoration: InputDecoration(hintText: 'user/recruiter',hintStyle: TextStyle(color: Colors.black38),prefixIcon: Icon(Icons.person),
                    enabledBorder: UnderlineInputBorder(borderSide: BorderSide(color: Colors.black38))),
              ),
            ),
            SizedBox(height: 30,),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 100),
              child: MaterialButton( color: Colors.amber,padding: EdgeInsets.all(15),
                onPressed: (){
                  EnterDetails(email.text.toString(), mobile.text.toString(), name.text.toString(), vendor_type.text.toString());
                }, child: Text('Submit',style: TextStyle(fontSize: 20,color: Colors.brown,fontWeight: FontWeight.bold),),
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.all(Radius.circular(20)),),),
            ),
            SizedBox(height: 20,),
            Center(child: Text(msg,style: TextStyle(color: Colors.red),)),
          ],
        ),
      ),
    );
  }
}
