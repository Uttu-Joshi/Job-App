import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import 'package:open_file/open_file.dart';
import 'package:path_provider/path_provider.dart';
import 'Profile.dart';
import 'package:dotted_border/dotted_border.dart';
import 'dart:async';
import 'dart:io';
import 'dart:convert';

class Upload extends StatefulWidget {
  const Upload({Key? key}) : super(key: key);

  @override
  State<Upload> createState() => _UploadState();
}

class _UploadState extends State<Upload> {
  @override
  Widget build(BuildContext context) {
    return SafeArea(child: Scaffold(
     appBar: AppBar(backgroundColor: Colors.amber,
       title: Text("Upload Resume",style: TextStyle(fontSize: 20,fontWeight: FontWeight.bold,color: Colors.white),),),
     body: Container(
       constraints: BoxConstraints(maxWidth: 800),
       padding: EdgeInsets.all(32),
       alignment: Alignment.center,
       child: ElevatedButton(
         child: Text("Pick File",style:TextStyle(fontSize: 20,fontWeight: FontWeight.bold,color: Colors.white) ,),
         onPressed: ()async{
           final result = await FilePicker.platform.pickFiles(allowMultiple: true);
           if(result == null) return;

           openFiles(result.files);

           final file = result.files.first;
           openFile(file);

           final newFile = await saveFilePernamently(file);

         },
       ),
     ),
    ));
  }

  void openFiles(List<PlatformFile> files){
   // Navigator.of(context).push(MaterialPageRoute(builder: (context)=> FilesPage(
   //   files: files
    //)));
  }

  void openFile(PlatformFile file){
    OpenFile.open(file.path!);
  }

  Future<File> saveFilePernamently(PlatformFile file) async{
       final appStorage = await getApplicationDocumentsDirectory();
       final newFile = File('${appStorage.path}/${file.name}');

       return File(file.path!).copy(newFile.path);

  }
}
