import 'dart:convert';
import 'dart:core';
import 'package:flutter/material.dart';
import 'package:http/http.dart'as http;
import 'applyData.dart';
import 'package:job/apply.dart';

import 'job1.dart';

class Spacecraft {
  final String position;
  final String company, image,concept,salary,city, requirement1,
      requirement2,skills;

  Spacecraft({
    required this.position,
    required this.company,
    required this.image,
    required this.concept,
    required this.salary,required this.city,
    required this.requirement1,
    required this.requirement2,
    required this.skills
  });

  factory Spacecraft.fromJson(Map<String, dynamic> jsonData) {
    return Spacecraft(
        position: jsonData['position'],
        company: jsonData['company'],
        //image: "http://192.168.1.7/job/upload/"+jsonData['image'],
        image: "https://otp-gen.000webhostapp.com/upload/"+jsonData['image'],
        concept: jsonData['concept'],
        salary: jsonData['salary'],
        city: jsonData['city'],
        requirement1: jsonData['requirement1'],
        requirement2: jsonData['requirement2'],
        skills: jsonData['skills']
    );
  }
}

class Searchjob {
  final String position;
  final String company, image;

  Searchjob({
   required this.position,
    required  this.company,
    required this.image,
  });

  factory Searchjob.fromJson(Map<String, dynamic> jsonData) {
    return Searchjob(
        position: jsonData['position'],
        company: jsonData['company'],
      //image: "http://192.168.1.7/job/upload/"+jsonData['image'],
      image: "https://otp-gen.000webhostapp.com/upload/"+jsonData['image'],
    );
  }
}


class Search extends StatefulWidget {
  const Search({Key? key}) : super(key: key);

  @override
  State<Search> createState() => _SearchState();
}

class _SearchState extends State<Search> {

  late List<Spacecraft> jobs = [];

  List searchList = [];

  Future showAllPost() async{
    //var url = "http://192.168.1.7/job/home.php";
   var url = "https://otp-gen.000webhostapp.com/home.php";
    var response = await http.get(Uri.parse(url));
    if(response.statusCode == 200){
      var jsonData = json.decode(response.body);
      for(var i = 0;i<jsonData.length;i++){
        searchList.add(jsonData[i]['position']);
      }
      print(searchList);
    }
  }

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    getApiData();
    showAllPost();
  }
  @override
  Widget build(BuildContext context) {
    return Scaffold( backgroundColor: Colors.grey[100],
      appBar: AppBar(
        iconTheme: IconThemeData(color: Colors.black),
        backgroundColor: Colors.amber,
        elevation: 1,
        actions: [
          IconButton(onPressed: (){
            showSearch(context: context, delegate: searchPost(list: searchList));
          }, icon: Icon(Icons.search)),
        ],
      ),
      body: SingleChildScrollView(
        child: Padding(
          padding: EdgeInsets.all(8),
          child: Column(
            children: [ SizedBox(height: 10,),
              Text('Popular Searches',style: TextStyle(color: Colors.black,fontWeight: FontWeight.bold,fontSize: 20),),
              SizedBox(height: 10,),
              Padding(
                padding: EdgeInsets.symmetric(horizontal: 2),
                child: Column(
                  children: buildLastJobs(),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  List<Widget> buildLastJobs(){
    List<Widget> list = [];
    for (var i = jobs.length -1; i > -1; i--) {
      list.add(buildLastJob(jobs[i]));
    }
    return list;
  }

  Widget buildLastJob(Spacecraft job){
    return GestureDetector(
      onTap: () {
         //  Navigator.push(context, MaterialPageRoute(builder: (context) => JobDetail(job: job)),);
      },
      child: Container(
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.all(
            Radius.circular(10),
          ),
        ),
        padding: EdgeInsets.all(16),
        margin: EdgeInsets.only(bottom: 16),
        child: Row(
          children: [

            Container(
              height: 60,
              width: 60,
              child: Column(
                children: [
                 // Image.network("http://192.168.1.7/job/upload/company.png")
                  Image.network("https://otp-gen.000webhostapp.com/company.png")
                ],
              ),
            ),

            Expanded(
                child: Padding(
                  padding: EdgeInsets.symmetric(horizontal: 24),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [

                      Text(
                        job.position,
                        style: TextStyle(
                          fontSize: 16,
                          fontWeight: FontWeight.bold,
                        ),
                      ),

                      Text(
                        job.company,
                        style: TextStyle(
                          fontSize: 14,
                          fontWeight: FontWeight.bold,
                          color: Colors.grey,
                        ),
                      ),

                    ],
                  ),
                )
            ),
          ],
        ),
      ),
    );
  }
  Future<void> getApiData() async{
   //String url = "http://192.168.1.7/job/home.php";
    String url = "https://otp-gen.000webhostapp.com/home.php";
    var result = await http.get(Uri.parse(url));
    jobs = jsonDecode(result.body)
        .map((item) => Spacecraft.fromJson(item))
        .toList()
        .cast<Spacecraft>();

    setState(() {

    });
  }
}

class searchPost extends SearchDelegate<String>{
  late List<dynamic> list;
  searchPost({required this.list});

  Future showAllPost() async{
   //var url = "http://192.168.1.7/job/search.php";
    var url = "https://otp-gen.000webhostapp.com/search.php";
    var response = await http.post(Uri.parse(url),
    body: {
      'position': query
    });
    if(response.statusCode == 200){
      var jsonData = json.decode(response.body);
      return jsonData;
    }
  }

  @override
  List<Widget>? buildActions(BuildContext context) {
    return [
      IconButton(onPressed: (){
          query = "";
          showSuggestions(context);
      }, icon: Icon(Icons.close)),
    ];
  }

  @override
  Widget? buildLeading(BuildContext context) {
     return IconButton(onPressed: (){}, icon: Icon(Icons.search));
  }

  @override
  Widget buildResults(BuildContext context) {
    return FutureBuilder( future: showAllPost(),
        builder: (context,AsyncSnapshot snapshot){
          if(snapshot.hasData){
            return ListView.builder(
                itemCount: snapshot.data.length,
                itemBuilder: (BuildContext context,int index){
                  var list = snapshot.data[index];
                  return Padding(padding: EdgeInsets.all(20),
                    child: Column( mainAxisAlignment: MainAxisAlignment.start,
                      children: [
                        Center(
                          child: Container(
                            height: 100,
                            width: 100,
                            child: Column(mainAxisAlignment: MainAxisAlignment.center,
                                children:[
                               // Image.network("http://192.168.1.7/job/upload/company.png"),
                        Image.network("https://otp-gen.000webhostapp.com/company.png")
                                ]
                            ),
                          ),
                        ),
                        SizedBox(height: 20,),
                        Text(
                          list['position'],style: TextStyle(
                          fontSize: 18,fontWeight: FontWeight.bold,
                        ),
                        ),
                        SizedBox(height: 20,),
                        Row(mainAxisAlignment: MainAxisAlignment.start,
                          children: [
                            Text('Requirements',style: TextStyle(fontSize: 20,fontWeight: FontWeight.bold),),
                          ],
                        ),
                        SizedBox(height: 20,),
                        Row(
                          children: [

                            Container(
                              width: 10,
                              height: 10,
                              decoration: BoxDecoration(
                                color: Colors.grey,
                                shape: BoxShape.circle,
                              ),
                            ),

                            SizedBox(
                              width: 16,
                            ),

                            Flexible(
                              child: Text(
                                list['requirement1']==null ? "" : list['requirement1'],
                                style: TextStyle(fontSize: 20,fontWeight: FontWeight.w500),
                              ),
                            ),

                          ],
                        ),
                        SizedBox(height: 20,),
                        Row(
                          children: [

                            Container(
                              width: 10,
                              height: 10,
                              decoration: BoxDecoration(
                                color: Colors.grey,
                                shape: BoxShape.circle,
                              ),
                            ),

                            SizedBox(
                              width: 16,
                            ),

                            Flexible(
                              child: Text(
                                list['requirement2']==null ? "" : list['requirement2'],
                                style: TextStyle(fontSize: 20,fontWeight: FontWeight.w500),
                              ),
                            ),

                          ],
                        ),
                        SizedBox(height: 20,),
                        Row(
                          children: [

                            Container(
                              width: 10,
                              height: 10,
                              decoration: BoxDecoration(
                                color: Colors.grey,
                                shape: BoxShape.circle,
                              ),
                            ),

                            SizedBox(
                              width: 16,
                            ),

                            Flexible(
                              child: Text(
                                list['skills required']==null ? "" : list['skills required'],
                                style: TextStyle(fontSize: 20,fontWeight: FontWeight.w500),
                              ),
                            ),

                          ],
                        ),
                        SizedBox(height: 150,),
                        Row(
                          children: [

                            //  Container(
                            //   height: 60,
                            // width: 60,
                            //  child: Center(
                            //   child: Icon(
                            //   Icons.group_rounded,
                            //  size: 28,
                            //),
                            //),
                            //),
                            Expanded(
                              child: GestureDetector(
                                onTap: (){
                                  Navigator.push(context, MaterialPageRoute(builder: (context) => Apply()),);
                                },
                                child: Container(
                                  height: 60,
                                  decoration: BoxDecoration(
                                    color: Colors.amber,
                                    borderRadius: BorderRadius.all(
                                      Radius.circular(10),
                                    ),
                                  ),
                                  child: Center(
                                    child: Text(
                                      "Apply Now",
                                      style: TextStyle(
                                        fontSize: 25,
                                        fontWeight: FontWeight.bold,
                                        color: Colors.white,
                                      ),
                                    ),
                                  ),
                                ),
                              ),
                            ),

                          ],
                        ),
                      ],
                    ),

                  );
                });
          }return CircularProgressIndicator();
        }
    );
  }

  @override
  Widget buildSuggestions(BuildContext context) {
   var listData = query.isEmpty ? list : list.where((element) => element.toLowerCase().contains(query)).toList();
    return listData.isEmpty ? Center(child: Text('No Data Found')) : ListView.builder(
      itemCount: listData.length,
      itemBuilder: (context,index){
        return ListTile(
            onTap: (){
              query = listData[index];
              showResults(context);
            },
            title: Text(listData[index]));
      }
    );
  }

}