import 'dart:convert';
import 'package:flutter/material.dart';
import 'applyData.dart';
import 'package:http/http.dart'as http;


class Oppturnities extends StatefulWidget {
  const Oppturnities({Key? key}) : super(key: key);

  @override
  State<Oppturnities> createState() => _OppturnitiesState();
}

class _OppturnitiesState extends State<Oppturnities> {

  List<Spacecraft> applications = [];

  List<Spacecraft> jobs = [];

  List<Spacecraft> applications2 = [];


  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    getApiData();
  }
  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        Padding(
          padding: EdgeInsets.only(right: 32, left: 32, top: 30, bottom: 20),
        ),
        Expanded(
          child: SingleChildScrollView(
            physics: BouncingScrollPhysics(),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [

                Padding(
                  padding: EdgeInsets.symmetric(horizontal: 20,vertical: 5),

                  child: Row( mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Text(
                        "Explore The Opportunities...",
                        style: TextStyle(
                            fontSize: 20,
                            fontWeight: FontWeight.bold,
                            height: 1.2
                        ),
                      ),
                    ],
                  ),
                ),

                Padding(
                  padding: EdgeInsets.symmetric(horizontal: 20),
                  child: Row( mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Text(
                        "Projects Matching Your Skills",
                        style: TextStyle(
                          fontSize: 18,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                      IconButton(onPressed: (){}, icon: Icon(Icons.arrow_forward_ios))
                    ],
                  ),
                ),

                Container(
                  height: 190,
                  child: ListView(
                    physics: BouncingScrollPhysics(),
                    scrollDirection: Axis.horizontal,
                    children: buildRecommendations(),
                  ),
                ),

                Padding(
                  padding: EdgeInsets.symmetric(horizontal: 20, vertical: 5),
                  child: Row( mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Text(
                        "Training and Certifications",
                        style: TextStyle(
                          fontSize: 18,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                      IconButton(onPressed: (){}, icon: Icon(Icons.arrow_forward_ios))
                    ],
                  ),
                ),
                Padding(
                  padding: EdgeInsets.symmetric(horizontal: 10),
                  child: Column(
                    children: buildApplications(),
                  ),
                ),
                SizedBox(height: 20,),
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 20,vertical: 5),
                  child: Row( mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Text(
                        "Services Offered...",
                        style: TextStyle(
                            fontSize: 18,
                            fontWeight: FontWeight.bold,
                            height: 1.2
                        ),
                      ),
                      IconButton(onPressed: (){}, icon: Icon(Icons.arrow_forward_ios))
                    ],
                  ),
                ),SizedBox(height: 10,),
                Padding(
                  padding: EdgeInsets.symmetric(horizontal: 10),
                  child: Column(
                    children: buildApplications2(),
                  ),
                ),

              ],
            ),
          ),
        ),

      ],
    );
  }
  List<Widget> buildRecommendations(){
    List<Widget> list = [];
    list.add(SizedBox(width: 32,));
    for (var i = 0; i < applications.length; i++) {
      list.add(buildRecommendation(applications[i]));
    }
    list.add(SizedBox(width: 10,));
    return list;
  }

  Widget buildRecommendation(Spacecraft job){
    return GestureDetector(
      onTap: () {
      },
      child: Container(
        width: 200,
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.all(
            Radius.circular(10),
          ),
        ),
        padding: EdgeInsets.all(16),
        margin: EdgeInsets.only(right: 16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [

                Container(
                  height: 50,
                  width: 50,
                  child: Column(
                    children: [
                   // Image.network(job.image),
                      Image.network("https://otp-gen.000webhostapp.com/company.png")
                    ],
                  ),
                ),

                Container(
                  decoration: BoxDecoration(
                    color: Colors.grey[200],
                    borderRadius: BorderRadius.all(
                      Radius.circular(10),
                    ),
                  ),
                  child: Padding(
                    padding: EdgeInsets.symmetric(horizontal: 12, vertical: 4,),
                    child: Text(
                      job.concept,
                      style: TextStyle(
                        fontWeight: FontWeight.bold,
                        fontSize: 14,
                      ),
                    ),
                  ),
                ),

              ],
            ),

            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisAlignment: MainAxisAlignment.end,
                children: [

                  Text(
                    job.position,
                    style: TextStyle(
                      fontWeight: FontWeight.bold,
                      fontSize: 16,
                    ),
                  ),

                  SizedBox(
                    height: 8,
                  ),

                  Text(
                    r"" + job.salary + "",
                    style: TextStyle(
                      fontWeight: FontWeight.bold,
                      fontSize: 15,
                    ),
                  ),
                ],
              ),
            )

          ],
        ),
      ),
    );
  }

  List<Widget> buildApplications(){
    List<Widget> list = [];
    for (var i = 0; i < applications.length-4; i++) {
      list.add(buildApplication(applications[i]));
    }
    return list;
  }

  Widget buildApplication(Spacecraft application){
    return Container(
      padding: EdgeInsets.all(8),
      margin: EdgeInsets.symmetric(vertical: 2),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.all(
          Radius.circular(10),
        ),
      ),
      child: Column(
        children: [

          Row(
            children: [

              Container(
                height: 60,
                width: 60,
                child: Column(
                  children: [
                   //Image.network("http://192.168.1.7/job/upload/company.png")
                    Image.network("https://otp-gen.000webhostapp.com/company.png")
                  ],
                ),
              ),

              Expanded(
                  child: Padding(
                    padding: EdgeInsets.symmetric(horizontal: 24),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [

                        Text(
                          application.position,
                          style: TextStyle(
                            fontSize: 14,
                            fontWeight: FontWeight.bold,
                          ),
                        ),

                        Text(
                          application.company,
                          style: TextStyle(
                            fontSize: 11,
                            fontWeight: FontWeight.bold,
                            color: Colors.grey,
                          ),
                        ),

                      ],
                    ),
                  )
              ),

              Icon(
                Icons.more_vert,
              ),


            ],
          ),

          SizedBox(
            height: 16,
          ),

        ],
      ),
    );
  }

  List<Widget> buildApplications2(){
    List<Widget> list = [];
    for (var i = 0; i < applications.length-3; i++) {
      list.add(buildApplication(applications[i]));
    }
    return list;
  }

  Widget buildApplication2(Application application){
    return Container(
      padding: EdgeInsets.all(8),
      margin: EdgeInsets.symmetric(vertical: 2),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.all(
          Radius.circular(10),
        ),
      ),
      child: Column(
        children: [

          Row(
            children: [
              Container(
                height: 60,
                width: 60,
                child: Column(
                  children: [
                    //Image.network("http://192.168.1.7/job/upload/company.png")
                   Image.network("https://otp-gen.000webhostapp.com/company.png")
                  ],
                ),
              ),

              Expanded(
                  child: Padding(
                    padding: EdgeInsets.symmetric(horizontal: 24),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [

                        Text(
                          application.position,
                          style: TextStyle(
                            fontSize: 14,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                        SizedBox(height: 50,),
                        Text(
                          application.company,
                          style: TextStyle(
                            fontSize: 11,
                            fontWeight: FontWeight.bold,
                            color: Colors.grey,
                          ),
                        ),

                      ],
                    ),
                  )
              ),

              Icon(
                Icons.more_vert,
              ),
            ],
          ),

          SizedBox(
            height: 16,
          ),

        ],
      ),
    );
  }

  Future<void> getApiData() async{
    //String url = "http://192.168.1.7/job/home.php";
   String url = "https://otp-gen.000webhostapp.com/home.php";
    var result = await http.get(Uri.parse(url));
    applications = jsonDecode(result.body)
        .map((item) => Spacecraft.fromJson(item))
        .toList()
        .cast<Spacecraft>();

    setState(() {

    });
  }

}
