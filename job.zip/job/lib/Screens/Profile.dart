import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:job/Screens/addprofile.dart';
import 'Resume.dart';

class Prof{
  late final String name,email,skills,jobpref1,jobpref2,experience1,experience2,experience3,eduinfo,personal,projects,awards;

  Prof({required this.name,required this.email,
  required this.skills,required this.jobpref1,required this.jobpref2,
  required this.experience1,required this.experience2,required this.experience3,
  required this.eduinfo,required this.personal,required this.projects,required this.awards});

  factory Prof.fromJson(Map<String, dynamic> jsonData) {
    return Prof(
        name: jsonData['name'],
        email: jsonData['email'],
        skills: jsonData['skills'],
        jobpref1: jsonData['jobpref1'], jobpref2: jsonData['jobpref2'],experience1: jsonData['experience1'],experience2: jsonData['experience2'],
        experience3: jsonData['experience3'],eduinfo: jsonData['eduinfo'],personal: jsonData['personal'],projects: jsonData['projects'],
        awards: jsonData['awards']
    );
  }

}

class Profile extends StatefulWidget {
  const Profile({Key? key}) : super(key: key);

  @override
  State<Profile> createState() => _ProfileState();
}

class _ProfileState extends State<Profile> {

  late List<Prof> prof = [];

  @override
  Widget build(BuildContext context) {
    return Scaffold(backgroundColor: Colors.grey[300],
      appBar: AppBar(
        backgroundColor: Colors.amber,
        elevation: 1,
        leading: IconButton(
          icon: Icon(Icons.arrow_back,color: Colors.white,),
          onPressed: (){},),
        actions: [
          IconButton(
            icon: Icon(
              Icons.settings,
              color: Colors.white,
            ),
            onPressed: () {
              Navigator.push(context, MaterialPageRoute(builder: (context)=>profile(),));
            },),
        ],
      ),
      body:ListView(
        children:[
          Container(
            color: Colors.amber, height: MediaQuery.of(context).size.height*0.3,
            width: double.infinity,
            child: Column(
              children: [Padding(padding: EdgeInsets.all(10),),
                Stack(children:[ CircleAvatar(radius: 70,backgroundImage: AssetImage('images/mos.jpg'),),
                  Positioned(bottom: 5,right: 5,child: CircleAvatar(backgroundColor: Colors.grey[200],
                   radius: 20,child: IconButton(icon: Icon(Icons.edit,color: Colors.green,), onPressed: () {
                     // Navigator.push(context, MaterialPageRoute(builder: (context)=>UploadImage(),));
                    },),)
                )
                ]),
                SizedBox(height: 10,),
                Text('Name Here',style: TextStyle(fontSize: 20,color: Colors.white),),SizedBox(height: 5,),
                Text('Job Title Here',style: TextStyle(fontSize: 18,color: Colors.white),),
              ],
            ),
          ),SizedBox(height: 10,),
           Container( padding: EdgeInsets.only(top: 10,bottom: 10,left: 16,right: 16),
             color: Colors.white,
             child: Column(
               crossAxisAlignment: CrossAxisAlignment.start,
               children: [Row(
                 mainAxisAlignment: MainAxisAlignment.spaceBetween, 
                 
                 children:[
                 Text('Resume',style: TextStyle(fontSize: 20,color: Colors.black,fontWeight: FontWeight.bold),),
                 SizedBox(width: 50,),
                 IconButton(onPressed: (){ Navigator.push(context, MaterialPageRoute(builder: (context)=>Upload(),)); },
                   icon: Icon(Icons.upload,color: Colors.blue,),),
               ],),
               ],
             ),
           ),
          SizedBox(height: 10,),
          Container(padding: EdgeInsets.only(top: 10,bottom: 10,left: 16,right: 16),
          color: Colors.white,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text('Skills',style: TextStyle(fontSize: 20,color: Colors.black,fontWeight: FontWeight.bold),),
                SizedBox(width: 50,),
                IconButton(onPressed: (){
                  openDialog();
                }, icon: Icon(Icons.edit,color: Colors.blue,),),
              ],
            )],
          ),),SizedBox(height: 10,),
          Container(padding: EdgeInsets.only(top: 20,bottom: 20,left: 16,right: 16),
            color: Colors.white,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text('Job Preferences',style: TextStyle(fontSize: 20,color: Colors.black,fontWeight: FontWeight.bold),),
                  IconButton(onPressed: (){
                    openDialog1();
                  },icon: Icon(Icons.edit),)
                ],
              ),
                Text('Add Jobs to let employer know your choice',style: TextStyle(fontWeight: FontWeight.w300),)
              ],
            ),),
          SizedBox(height: 10,),
          Container(padding: EdgeInsets.only(top: 30,bottom: 30,left: 16,right: 16),
            color: Colors.white,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text('Work Experience',style: TextStyle(fontSize: 20,color: Colors.black,fontWeight: FontWeight.bold),),
                  IconButton(onPressed: (){
                    openDialog2();
                  }, icon: Icon(Icons.edit,color: Colors.blue,),),
                ],
              ), Text('Help recuriters map your candidature against job vacancies',style: TextStyle(fontWeight: FontWeight.w300),),],
            ),),SizedBox(height: 10,),
          Container(padding: EdgeInsets.only(top: 30,bottom: 30,left: 16,right: 16),
            color: Colors.white,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text('Educational Information',style: TextStyle(fontSize: 20,color: Colors.black,fontWeight: FontWeight.bold),),
                  IconButton(onPressed: (){

                  }, icon: Icon(Icons.edit,color: Colors.blue,),),
                ],),
                Text('Add your school,collge and higher edication details',style: TextStyle(fontWeight: FontWeight.w300),)],
            ),),
          SizedBox(height: 10),
          Container(padding: EdgeInsets.only(top: 20,bottom: 20,left: 16,right: 16),
            color: Colors.white,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text('Personal Details',style: TextStyle(fontSize: 20,color: Colors.black,fontWeight: FontWeight.bold),),
                  SizedBox(width: 50,),
                  IconButton(onPressed: (){}, icon: Icon(Icons.add,color: Colors.blue,),),
                ],
              ),Text('List Personal Details like date of birth,gender etc.',style: TextStyle(fontWeight: FontWeight.w300),)],
            ),),SizedBox(height: 10,),
          Container(padding: EdgeInsets.only(top: 20,bottom: 20,left: 16,right: 16),
            color: Colors.white,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text('Projects',style: TextStyle(fontSize: 20,color: Colors.black,fontWeight: FontWeight.bold),),
                  IconButton(onPressed: (){}, icon: Icon(Icons.add,color: Colors.blue,),)
                ],
              ),Text('Add Projects you want to showcase',style: TextStyle(fontWeight: FontWeight.w300),),],
            ),), SizedBox(height: 10,),
          Container(padding: EdgeInsets.only(top: 20,bottom: 20,left: 16,right: 16),
            color: Colors.white,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text('Awards and Achievements',style: TextStyle(fontSize: 20,color: Colors.black,fontWeight: FontWeight.bold),),
                  IconButton(onPressed: (){}, icon: Icon(Icons.edit,color: Colors.blue,),),
                ],
              ), Text('Add Projects you want to showcase',style: TextStyle(fontWeight: FontWeight.w300),),],
            ),),
          ],
      )
    );
  }
  Future openDialog() => showDialog(context: context, builder: (context) => AlertDialog(
    title: Text('Your Name'),
    content: TextField(
      decoration: InputDecoration(hintText: 'Enter your name'),
    ),actions: [
      TextButton(
        child: Text('Submit'),
        onPressed: (){},
      )
  ],
  ));

  Future openDialog1() => showDialog(context: context, builder: (context) => AlertDialog(
    title: Text('Your Name'),
    content: TextField(
      decoration: InputDecoration(hintText: 'Enter your preferences in 100 characters'),
    ),actions: [
    TextButton(
      child: Text('Submit'),
      onPressed: (){},
    )
  ],
  ));

  Future openDialog2() => showDialog(context: context, builder: (context) => AlertDialog(
    title: Text('Your Name'),
    content: TextField(
      decoration: InputDecoration(hintText: 'Add Work Experience(100 characters)'),
    ),actions: [
    TextButton(
      child: Text('Submit'),
      onPressed: (){},
    )
  ],
  ));

  Future openDialog3() => showDialog(context: context, builder: (context) => AlertDialog(
    title: Text('Your Name'),
    content: TextField(
      decoration: InputDecoration(hintText: 'Add Work Experience(100 characters)'),
    ),actions: [
    TextButton(
      child: Text('Submit'),
      onPressed: (){},
    )
  ],
  ));
}
