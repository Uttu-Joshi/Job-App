class Spacecraft {
  final String position;
  final String company, image,status,salary,city;

  Spacecraft({
    required this.position,
    required this.company,
    required this.image,
    required this.status,
    required this.salary,
    required this.city,
  });

  factory Spacecraft.fromJson(Map<String, dynamic> jsonData) {
    return Spacecraft(
        position: jsonData['position'],
        company: jsonData['company'],
      //image: "http://192.168.1.7/job/upload/"+jsonData['image'],
      image: "https://otp-gen.000webhostapp.com/upload/"+jsonData['image'],
        status: jsonData['status'],
        salary: jsonData['salary'],
        city: jsonData['city'],
    );
  }
}


// For UI Only

class Application {

  String position;
  String company;
  String status;
  String price;
  String logo;

  Application(this.position, this.company, this.status, this.price, this.logo);

}

List<Application> getApplications(){
  return <Application>[
    Application("Product Designer", "Google LLC", "Opened", "6", "images/go.jpg"),
    Application("UI / UX Designer", "Uber Technologies Inc.", "Cancelled", "5", "images/uber.png"),
    Application("Lead UI / UX Designer", "Apple Inc.", "Delivered", "8", "images/apple.png"),
    Application("Flutter UI Designer", "Amazon Inc.", "Not selected", "6", "images/amazon.jpg"),
    Application("Flutter UI Designer", "Amazon Inc.", "Not selected", "6", "images/amazon.jpg"),
  ];
}

class Job {

  String position;
  String company;
  String price;
  String concept;
  String logo;
  String city;

  Job(this.position, this.company, this.price, this.concept, this.logo, this.city);

}

List<Job> getJobs(){
  return <Job>[
    Job("Product Designer", "Google LLC", "6", "Part-Time", "images/go.jpg", "Noida, India"),
    Job("UI / UX Designer", "Uber Technologies Inc.", "5", "Full-Time", "images/uber.png", "New Delhi, India"),
    Job("Lead UI/UX Designer", "Apple Inc.", "8", "Part-Time", "images/apple.png", "San Francisco, California"),
    Job("Flutter Developer", "Amazon Inc.", "6", "Full-Time", "images/amazon.jpg", "Mumbai, India"),
    Job("Flutter Developer", "Amazon Inc.", "6", "Full-Time", "images/amazon.jpg", "Mumbai, India"),
  ];
}

List<String> getJobsRequirements(){
  return <String>[
    "Exceptional communication skills and team-working skills",
    "Know the principles of animation and you can create high fidelity prototypes",
    "Direct experience using Adobe Premiere, Adobe After Effects & other tools used to create videos, animations, etc.",
    "Good UI/UX knowledge",
  ];
}

class SearchModel{
    late String position;
    late String logo;
    late String company;
    late String salary;

    SearchModel(this.position,this.logo,this.company,this.salary);

}

List<Application> getApplications1(){
  return <Application>[
    Application("Graphic Designing", "Coursera", "Opened", "6", "images/company.png"),
    Application("Ui/Ux Designing", "Coursera", "Cancelled", "5", "images/company.png"),

  ];
}

List<Job> getJobs1(){
  return <Job>[
    Job("Product Designer", "Google LLC", "6", "Part-Time", "images/company.png", "Noida, India"),
    Job("UI / UX Designer", "Uber Technologies Inc.", "5", "Full-Time", "images/company.png", "New Delhi, India"),
    Job("Lead UI/UX Designer", "Apple Inc.", "8", "Part-Time", "images/company.png", "San Francisco, California"),
  ];
}