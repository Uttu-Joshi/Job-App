import 'dart:convert';
import 'package:http/http.dart' as http;
import 'package:flutter/material.dart';
import 'data.dart';
import 'job1.dart';
import 'Search.dart';
import 'Search2.dart';

class Spacecraft {
  final String position;
  final String company, image,concept,salary,city, requirement1,
      requirement2,skills;

  Spacecraft({
    required this.position,
    required this.company,
    required this.image,
    required this.concept,
    required this.salary,required this.city,
    required this.requirement1,
    required this.requirement2,
    required this.skills
  });

  factory Spacecraft.fromJson(Map<String, dynamic> jsonData) {
    return Spacecraft(
        position: jsonData['position'],
        company: jsonData['company'],
       //image: "http://192.168.1.7/job/upload/"+jsonData['image'],
        image: "https://otp-gen.000webhostapp.com/upload/"+jsonData['image'],
        concept: jsonData['concept'],
        salary: jsonData['salary'],
        city: jsonData['city'],
       requirement1: jsonData['requirement1'],
        requirement2: jsonData['requirement2'],
      skills: jsonData['skills']
    );
  }
}

class Jobs extends StatefulWidget {
  @override
  _JobsState createState() => _JobsState();
}

class _JobsState extends State<Jobs> {
  TextEditingController search = new TextEditingController();

  late List<Spacecraft> jobs = [];

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    getApiData();
  }
  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        Padding(
          padding: EdgeInsets.only(right: 32, left: 32, top: 30, bottom: 20),
        ),
        Expanded(
          child: SingleChildScrollView(
            physics: BouncingScrollPhysics(),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [

                Padding(
                  padding: EdgeInsets.only(right: 32, left: 32, bottom: 10),

                    child: Row( mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Text(
                          "Search your desired Job...",
                          style: TextStyle(
                              fontSize: 20,
                              fontWeight: FontWeight.bold,
                              height: 1.2
                          ),
                        ),
                        IconButton(onPressed: (){},icon: Icon(Icons.sort)),
                      ],
                    ),
                  ),

                Padding(
                  padding: EdgeInsets.symmetric(horizontal: 32),
                  child: GestureDetector(
                    onTap: (){
                      Navigator.push(context, MaterialPageRoute(builder: (context) => Search()),);
                    },
                    child: Container(
                      alignment: Alignment.center,
                      width: 400,
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(20),
                        color: Colors.white,
                      ),
                      child: Padding(
                        padding: EdgeInsets.fromLTRB(15, 5, 30, 5),
                        child: Row(
                          children: [
                            IconButton( onPressed: (){},
                                icon: Icon(Icons.search)),
                            Text(
                              "Search your desired job...", style: TextStyle(fontWeight: FontWeight.bold, color: Colors.black38,fontSize: 15),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ),
                ),

                Padding(
                  padding: EdgeInsets.symmetric(horizontal: 32, vertical: 16),
                  child: Text(
                    "Recommended for you",
                    style: TextStyle(
                      fontSize: 18,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ),

                Container(
                  height: 190,
                  child: ListView(
                    physics: BouncingScrollPhysics(),
                    scrollDirection: Axis.horizontal,
                    children: buildRecommendations(),
                  ),
                ),

                Padding(
                  padding: EdgeInsets.symmetric(horizontal: 32, vertical: 16),
                  child: Text(
                    "Recently added",
                    style: TextStyle(
                      fontSize: 18,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ),

                Padding(
                  padding: EdgeInsets.symmetric(horizontal: 32),
                  child: Column(
                    children: buildLastJobs(),
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 20),
                  child: Container(
                    decoration: BoxDecoration( borderRadius: BorderRadius.circular(20),
                        color: Colors.grey),
                    height: 100,
                    child: ListView(
                      physics: BouncingScrollPhysics(),
                      scrollDirection: Axis.horizontal,
                      children: [
                        Text('Add Here', style: TextStyle(fontSize: 30,color: Colors.white,fontWeight: FontWeight.bold),),
                      ],
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),

      ],
    );
  }

  List<Widget> buildRecommendations(){
    List<Widget> list = [];
    list.add(SizedBox(width: 32,));
    for (var i = 0; i < jobs.length; i++) {
      list.add(buildRecommendation(jobs[i]));
    }
    list.add(SizedBox(width: 10,));
    return list;
  }

  Widget buildRecommendation(Spacecraft job){
    return GestureDetector(
      onTap: () {
        Navigator.push(context, MaterialPageRoute(builder: (context) => JobDetail(job: job)),);
      },
      child: Container(
        width: 200,
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.all(
            Radius.circular(10),
          ),
        ),
        padding: EdgeInsets.all(16),
        margin: EdgeInsets.only(right: 16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [

            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [

                Container(
                  height: 60,
                  width: 60,
                  child: Column(
                    children: [
                     //Image.network("http://192.168.1.7/job/upload/company.png")
                      Image.network("https://otp-gen.000webhostapp.com/company.png")
                    ],
                  ),
                ),
                Container(
                  decoration: BoxDecoration(
                    color: Colors.grey[200],
                    borderRadius: BorderRadius.all(
                      Radius.circular(10),
                    ),
                  ),
                  child: Padding(
                    padding: EdgeInsets.symmetric(horizontal: 12, vertical: 4,),
                    child: Text(
                      job.concept,
                      style: TextStyle(
                        fontWeight: FontWeight.bold,
                        fontSize: 14,
                      ),
                    ),
                  ),
                ),

              ],
            ),

            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisAlignment: MainAxisAlignment.end,
                children: [

                  Text(
                    job.position,
                    style: TextStyle(
                      fontWeight: FontWeight.bold,
                      fontSize: 16,
                    ),
                  ),

                  SizedBox(
                    height: 8,
                  ),

                  Text(
                    r"" + job.salary + "",
                    style: TextStyle(
                      fontWeight: FontWeight.bold,
                      fontSize: 15,
                    ),
                  ),
                ],
              ),
            )

          ],
        ),
      ),
    );
  }

  List<Widget> buildLastJobs(){
    List<Widget> list = [];
    for (var i = jobs.length - 3; i > -1; i--) {
      list.add(buildLastJob(jobs[i]));
    }
    return list;
  }

  Widget buildLastJob(Spacecraft job){
    return GestureDetector(
      onTap: () {
        Navigator.push(context, MaterialPageRoute(builder: (context) => JobDetail(job: job)),);
      },
      child: Container(
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.all(
            Radius.circular(10),
          ),
        ),
        padding: EdgeInsets.all(16),
        margin: EdgeInsets.only(bottom: 16),
        child: Row(
          children: [

            Container(
              height: 60,
              width: 60,
              child: Column(
                children: [
                 //Image.network("http://192.168.1.7/job/upload/company.png"),
                  Image.network("https://otp-gen.000webhostapp.com/company.png")
                ],
              ),
            ),

            Expanded(
                child: Padding(
                  padding: EdgeInsets.symmetric(horizontal: 24),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [

                      Text(
                        job.position,
                        style: TextStyle(
                          fontSize: 16,
                          fontWeight: FontWeight.bold,
                        ),
                      ),

                      Text(
                        job.company,
                        style: TextStyle(
                          fontSize: 14,
                          fontWeight: FontWeight.bold,
                          color: Colors.grey,
                        ),
                      ),
                    ],
                  ),
                )
            ),

            Text(
              r"" + job.salary + "",
              style: TextStyle(
                fontSize: 16,
              ),
            ),

          ],
        ),
      ),
    );
  }
  Future<void> getApiData() async{
    //String url = "http://192.168.1.7/job/home.php";
    String url = "https://otp-gen.000webhostapp.com/home.php";
    var result = await http.get(Uri.parse(url));
    jobs = jsonDecode(result.body)
        .map((item) => Spacecraft.fromJson(item))
        .toList()
        .cast<Spacecraft>();

    setState(() {

    });
  }
}

