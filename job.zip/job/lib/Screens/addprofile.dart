import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:http/http.dart'as http;

class profile extends StatefulWidget {
  const profile({Key? key}) : super(key: key);

  @override
  State<profile> createState() => _profileState();
}

class _profileState extends State<profile> {
  TextEditingController name = new TextEditingController();
  TextEditingController email = new TextEditingController();
  TextEditingController skills = new TextEditingController();
  TextEditingController jobpref1 = new TextEditingController();
  TextEditingController jobpref2 = new TextEditingController();
  TextEditingController workexp = new TextEditingController();
  TextEditingController eduinfo = new TextEditingController();
  TextEditingController personal = new TextEditingController();
  TextEditingController projects = new TextEditingController();
  TextEditingController awardsachieve = new TextEditingController();
  TextEditingController workexp1 = new TextEditingController();
  TextEditingController workexp2 = new TextEditingController();

  String msg = '';

  Future submit() async{
    //var url = "http://192.168.1.7/job/profile.php";
    var url = "https://otp-gen.000webhostapp.com/profile.php";
    final response = await http.post(Uri.parse(url),body: {
      "email" : email.text, "name" : name.text,
      "skills" : skills.text, "jobpref1": jobpref1.text, "workexp1":workexp1.text, "jobpref2": jobpref2.text,
      "workexp2": workexp2.text, "workexp": workexp.text,
      "eduinfo" : eduinfo.text, "personal": personal.text, "projects":projects.text, "awards":awardsachieve.text,
    });
    var datauser = json.decode(response.body);
    if(datauser == "Error"){
      setState(() {
        msg = "Invalid Essentials";
      });
    }else{
      print("Connection Established");
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Padding(
        padding: EdgeInsets.symmetric(horizontal: 5),
        child: ListView(
          children: [
            SizedBox(height: 25,),
            Text('Enter Your Details',style: TextStyle(color: Colors.amber,fontSize: 20,fontWeight: FontWeight.bold),textAlign: TextAlign.center,),
            SizedBox(height: 25,),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 20),
              child: TextField(
                controller: name,
                decoration: InputDecoration(hintText: 'Name...',hintStyle: TextStyle(color: Colors.black38),
                    prefixIcon: Icon(Icons.person),enabledBorder: UnderlineInputBorder(borderSide: BorderSide(color: Colors.black38))),
              ),
            ),
            SizedBox(height: 25,),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 20),
              child: TextField(
                controller: email,
                decoration: InputDecoration(hintText: 'E-mail',hintStyle: TextStyle(color: Colors.black38),
                    prefixIcon: Icon(Icons.email),enabledBorder: UnderlineInputBorder(borderSide: BorderSide(color: Colors.black38))),
              ),
            ),
            SizedBox(height: 25,),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 20),
              child: TextField(
                controller: skills,
                decoration: InputDecoration(hintText: 'Enter your skills',hintStyle: TextStyle(color: Colors.black38),
                    prefixIcon: Icon(Icons.edit),enabledBorder: UnderlineInputBorder(borderSide: BorderSide(color: Colors.black38))),
              ),
            ),
            SizedBox(height: 25,),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 20),
              child: TextField(
                controller: jobpref1,
                decoration: InputDecoration(hintText: 'Enter your job preference 1',hintStyle: TextStyle(color: Colors.black38),
                    prefixIcon: Icon(Icons.luggage),enabledBorder: UnderlineInputBorder(borderSide: BorderSide(color: Colors.black38))),
              ),
            ),
            SizedBox(height: 25,),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 20),
              child: TextField(
                controller: jobpref2,
                decoration: InputDecoration(hintText: 'Enter your job preference 2',hintStyle: TextStyle(color: Colors.black38),
                    prefixIcon: Icon(Icons.luggage),enabledBorder: UnderlineInputBorder(borderSide: BorderSide(color: Colors.black38))),
              ),
            ),
            SizedBox(height: 25,),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 20),
              child: TextField(
                controller: workexp,
                decoration: InputDecoration(hintText: 'Work Experience 1',hintStyle: TextStyle(color: Colors.black38),
                    prefixIcon: Icon(Icons.baby_changing_station),enabledBorder: UnderlineInputBorder(borderSide: BorderSide(color: Colors.black38))),
              ),
            ),
            SizedBox(height: 25,),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 20),
              child: TextField(
                controller: workexp1,
                decoration: InputDecoration(hintText: 'Work Experience 2',hintStyle: TextStyle(color: Colors.black38),
                    prefixIcon: Icon(Icons.baby_changing_station),enabledBorder: UnderlineInputBorder(borderSide: BorderSide(color: Colors.black38))),
              ),
            ),
            SizedBox(height: 25,),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 20),
              child: TextField(
                controller: workexp2,
                decoration: InputDecoration(hintText: 'Work Experience 3',hintStyle: TextStyle(color: Colors.black38),
                    prefixIcon: Icon(Icons.baby_changing_station),enabledBorder: UnderlineInputBorder(borderSide: BorderSide(color: Colors.black38))),
              ),
            ),
            SizedBox(height: 25,),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 20),
              child: TextField(
                controller: eduinfo,
                decoration: InputDecoration(hintText: 'Enter your educational infromation',hintStyle: TextStyle(color: Colors.black38),
                    prefixIcon: Icon(Icons.library_books),enabledBorder: UnderlineInputBorder(borderSide: BorderSide(color: Colors.black38))),
              ),
            ),
            SizedBox(height: 25,),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 20),
              child: TextField(
                controller: personal,
                decoration: InputDecoration(hintText: 'Enter your personal Details',hintStyle: TextStyle(color: Colors.black38),
                    prefixIcon: Icon(Icons.edit),enabledBorder: UnderlineInputBorder(borderSide: BorderSide(color: Colors.black38))),
              ),
            ),
            SizedBox(height: 25,),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 20),
              child: TextField(
                controller: projects,
                decoration: InputDecoration(hintText: 'Enter your projects',hintStyle: TextStyle(color: Colors.black38),
                    prefixIcon: Icon(Icons.edit),enabledBorder: UnderlineInputBorder(borderSide: BorderSide(color: Colors.black38))),
              ),
            ),
            SizedBox(height: 25,),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 20),
              child: TextField(
                controller: awardsachieve,
                decoration: InputDecoration(hintText: 'Enter your achievements',hintStyle: TextStyle(color: Colors.black38),
                    prefixIcon: Icon(Icons.wine_bar),enabledBorder: UnderlineInputBorder(borderSide: BorderSide(color: Colors.black38))),
              ),
            ),
           SizedBox(height: 50,),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 140),
              child: MaterialButton( color: Colors.amber,padding: EdgeInsets.all(10),
                onPressed: (){
                  submit();
                },
                child: Text('Submit',style: TextStyle(fontSize: 20,color: Colors.brown,fontWeight: FontWeight.bold),),
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.all(Radius.circular(20)),),),
            ),
            SizedBox(height: 20,),
            ],
        ),
      ),
    );
  }
}
