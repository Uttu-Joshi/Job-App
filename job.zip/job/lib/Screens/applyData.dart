class Spacecraft {
  final String position;
  final String company, image,concept,salary,city,requirement1,requirement2,skills;

  Spacecraft({
    required this.position,
    required this.company,
    required this.image,
    required this.concept,
    required this.salary,
    required this.city, required this.skills, required this.requirement1,required this.requirement2
  });

  factory Spacecraft.fromJson(Map<String, dynamic> jsonData) {
    return Spacecraft(
        position: jsonData['position'],
        company: jsonData['company'],
      //image: "http://192.168.1.7/job/upload/"+jsonData['image'],
      image: "https://otp-gen.000webhostapp.com/upload/"+jsonData['image'],
        concept: jsonData['concept'],
        salary: jsonData['salary'],
        city: jsonData['city'],
        skills: jsonData['skills'],
        requirement1: jsonData['requirement1'],
        requirement2: jsonData['requirement2'],
    );
  }
}

class Application {

  String position;
  String company;
  String status;
  String price;
  String logo;

  Application(this.position, this.company, this.status, this.price, this.logo);

}