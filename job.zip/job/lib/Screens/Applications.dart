import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:job/Screens/Search.dart';

class Spacecraft {
  final String position;
  final String company, image,applystatus;

  Spacecraft({
    required this.position,
    required this.company,
    required this.image,
    required this.applystatus
  });

  factory Spacecraft.fromJson(Map<String, dynamic> jsonData) {
    return Spacecraft(
      position: jsonData['position'],
      company: jsonData['company'],
     //image: "http://192.168.1.7/job/upload/"+jsonData['image'],
      image: "https://otp-gen.000webhostapp.com/upload/"+jsonData['image'],
      applystatus: jsonData['applystatus']
    );
  }
}


class Applications extends StatefulWidget {
  @override
  _ApplicationsState createState() => _ApplicationsState();
}

class _ApplicationsState extends State<Applications> {

  late List<Spacecraft> applications=[];

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    getApiData();
  }

  @override
  Widget build(BuildContext context) {
    return SingleChildScrollView(
      physics: BouncingScrollPhysics(),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Padding(padding: EdgeInsets.only(right: 32, left: 32, top: 45),
            child: Row( mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text(
                  "Your Applications (" + applications.length.toString() + ")",
                  style: TextStyle(
                      fontSize: 20,
                      fontWeight: FontWeight.bold,
                      height: 1.2
                  ),
                ),
                Icon(Icons.sort),
              ],
            ),
          ),
          Padding(
            padding: EdgeInsets.symmetric(horizontal: 32),
            child: GestureDetector(
              onTap: (){
              //  Navigator.push(context, MaterialPageRoute(builder: (context)=> SearchBar()));
              },
              child: Container(
                alignment: Alignment.center,
                width: 400,
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(20),
                  color: Colors.white,
                ),
                child: Padding(
                  padding: EdgeInsets.fromLTRB(15, 15, 30, 15),
                  child: Row(
                    children: [
                      Icon(Icons.search),SizedBox(width: 10,),
                      Text(
                        "Search your desired job...", style: TextStyle(fontWeight: FontWeight.bold, color: Colors.black38,fontSize: 15),
                      ),
                    ],
                  ),
                ),
              ),
            ),
          ),

          Padding(
            padding: EdgeInsets.only(right: 10, left: 10, bottom: 8),
            child: Column(
              children: buildApplications1(),
            ),
          ),
        ],
      ),
    );
  }

  List<Widget> buildApplications1(){
    List<Widget> list = [];
    for (var i = 0; i < applications.length; i++) {
      list.add(buildApplication(applications[i]));
    }
    return list;
  }

  Widget buildApplication(Spacecraft application){
    return Container(
      padding: EdgeInsets.all(8),
      margin: EdgeInsets.symmetric(vertical: 2),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.all(
          Radius.circular(10),
        ),
      ),
      child: Column(
        children: [

          Row(
            children: [

              Container(
                height: 60,
                width: 60,
                child: Column(
                  children: [
                  //Image.network("http://192.168.1.7/job/upload/company.png")
                    Image.network("https://otp-gen.000webhostapp.com/company.png")
                  ],
                ),
              ),

              Expanded(
                  child: Padding(
                    padding: EdgeInsets.symmetric(horizontal: 24),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [

                        Text(
                          application.position,
                          style: TextStyle(
                            fontSize: 14,
                            fontWeight: FontWeight.bold,
                          ),
                        ),

                        Text(
                          application.company,
                          style: TextStyle(
                            fontSize: 11,
                            fontWeight: FontWeight.bold,
                            color: Colors.grey,
                          ),
                        ),

                      ],
                    ),
                  )
              ),

              Icon(
                Icons.more_vert,
              ),


            ],
          ),

          SizedBox(
            height: 16,
          ),

          Row(
            children: [

              Expanded(
                child: Container(
                  height: 30,
                  decoration: BoxDecoration(
                    color: Colors.grey[200],
                    borderRadius: BorderRadius.all(
                      Radius.circular(10),
                    ),
                  ),
                  child: Center(
                    child: Text(
                      application.applystatus,
                      style: TextStyle(
                        fontWeight: FontWeight.bold,
                        fontSize: 15,
                        color: application.applystatus == "Opened" ? Colors.green[500] :
                        application.applystatus == "Cancelled" ? Colors.red[500] : Colors.black,
                      ),
                    ),
                  ),
                ),
              ),

              Expanded(
                child: Container(
                  child: Center(
                    child: Text('',
                     // r"" + application.salary + "",
                      style: TextStyle(
                        fontSize: 14,
                      ),
                    ),
                  ),
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Future<void> getApiData() async{
    //String url = "http://192.168.1.7/job/application.php";
   String url = "https://otp-gen.000webhostapp.com/application.php";
    var result = await http.get(Uri.parse(url));
    applications = jsonDecode(result.body)
        .map((item) => Spacecraft.fromJson(item))
        .toList()
        .cast<Spacecraft>();

    setState(() {

    });
  }

}