import 'package:flutter/material.dart';

class OnlineButton extends StatelessWidget {
 late final String asset;
 late final VoidCallback onTap;

 OnlineButton(this.asset,this.onTap);

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () {},
      child: Image(image: AssetImage(asset),height: 40,),
    );

     // OutlineButton(onPressed: (){},
     // child: Image(image: AssetImage(asset),height: 35,),
      //shape: RoundedRectangleBorder(borderRadius: BorderRadius.all(Radius.circular(16)),),);
  }
}
