import 'package:flutter/material.dart';
import 'package:job/Profile/ButtonWidget.dart';
import 'package:job/Profile/ProfileData.dart';
import 'package:job/Profile/ProfileWidget.dart';
import 'package:job/Profile/TextFieldWidget.dart';
import 'package:job/Profile/UserPreferences.dart';
import 'package:job/Profile/buildAppBarProfile.dart';

class EditProfile extends StatefulWidget {
  const EditProfile({Key? key}) : super(key: key);

  @override
  State<EditProfile> createState() => _EditProfileState();
}

class _EditProfileState extends State<EditProfile> {
  UserData user = UserPreferences.myUser;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: buildAppBar(context),
      body: ListView(
        padding: EdgeInsets.symmetric(horizontal: 32),
        physics: BouncingScrollPhysics(),
        children: [
          SizedBox(height: 40,),
          ProfileWidget(
            isEdit: true,
            imagePath: user.imagePath, onClicked: () async {},
          ),
          SizedBox(height: 20,),
          TextFieldWidget(
            maxLines: 1,
            label: 'Full Name',
            text: user.name,
            onChanged: (name) => user = user.copy(name: name),
          ),
          SizedBox(height: 20,),
          TextFieldWidget(
            maxLines: 1,
            label: 'Email',
            text: user.email,
            onChanged: (email) => user = user.copy(email: email),
          ),
          SizedBox(height: 20,),
          TextFieldWidget(
            label: 'About',
            maxLines: 4,
            text: user.about,
            onChanged: (about) => user = user.copy(about: about),
          ),
          SizedBox(height: 20,),
          TextFieldWidget(
            maxLines: 1,
            label: 'WhatsApp Number',
            text: user.whatsapp,
            onChanged: (whatsapp) => user = user.copy(whatsapp: whatsapp),
          ),
          SizedBox(height: 20,),
          TextFieldWidget(
            maxLines: 1,
            label: 'Company',
            text: user.company,
            onChanged: (company) => user = user.copy(company: company),
          ),
          SizedBox(height: 20,),
          TextFieldWidget(
            maxLines: 1,
            label: 'Country',
            text: user.country,
            onChanged: (country) => user = user.copy(country: country),
          ),
          SizedBox(height: 20,),
          TextFieldWidget(
            maxLines: 1,
            label: 'State',
            text: user.state,
            onChanged: (state) => user = user.copy(state: state),
          ),
          SizedBox(height: 20,),
          TextFieldWidget(
            maxLines: 1,
            label: 'City',
            text: user.city,
            onChanged: (city) => user = user.copy(city: city),
          ),
          SizedBox(height: 20,),
          TextFieldWidget(
            maxLines: 1,
            label: 'PinCode',
            text: user.pincode,
            onChanged: (pincode) => user = user.copy(pincode: pincode),
          ),
          SizedBox(height: 40,),
          ButtonWidget(text: 'Save', onClicked: () {
            UserPreferences.setUSer(user);
            Navigator.pop(context);
          },),
        ],
      ),
    );
  }
}
