import 'package:flutter/material.dart';
import 'package:job/Dashboard.dart';
import 'package:job/Profile/EditProfile.dart';
import 'package:job/Profile/ButtonWidget.dart';
import 'package:job/Profile/ProfileData.dart';
import 'package:job/Profile/UserPreferences.dart';
import 'package:job/Profile/buildAppBarProfile.dart';
import 'package:job/RecDashboard.dart';

import 'ProfileWidget.dart';

class ProfilePage extends StatefulWidget {
  const ProfilePage({Key? key}) : super(key: key);

  @override
  State<ProfilePage> createState() => _ProfilePageState();
}

class _ProfilePageState extends State<ProfilePage> {
  @override
  Widget build(BuildContext context) {
    final user = UserPreferences.myUser;
    return Scaffold(
      appBar: buildAppBar(context),
      body: ListView(
        physics: BouncingScrollPhysics(),
        children: [
          SizedBox(height: 30,),
          ProfileWidget(
            imagePath: user.imagePath,
            onClicked: () async {
             await Navigator.of(context).push(
                MaterialPageRoute(builder: (context) => EditProfile()),
              );
             setState(() {

             });
            },
            isEdit: false,
          ),
          SizedBox(height: 24,),
          buildName(user),
          SizedBox(height: 24,),
          Center(child: buildUpGradeButton()),
          SizedBox(height: 48,),
          buildAboutUser(user),
          SizedBox(height: 10,),
          WhatsApp(user),
          SizedBox(height: 10,),
          buildCompany(user),
          SizedBox(height: 10,),
          buildContry(user),
          SizedBox(height: 10,),
          buildState(user),
          SizedBox(height: 10,),
          buildCity(user),
          SizedBox(height: 10,),
          buildpinCode(user),
        ],
      ),
    );
  }

  Widget buildName(UserData user) =>
       Padding(
         padding: const EdgeInsets.all(8.0),
         child: Column(
            children: [
              Text(user.name,
              style: TextStyle(fontWeight: FontWeight.bold,fontSize: 17),
              ),
              SizedBox(height: 4,),
              Text(user.email,
                style: TextStyle(color: Colors.grey),
              ),
            ],

  ),
       );


  Widget buildUpGradeButton() => ButtonWidget(
    text: 'Skip this Step',onClicked:(){
      Navigator.push(context, MaterialPageRoute(builder: (context)=> DashBoard(),));
  },
  );

  Widget buildAboutUser(UserData user) => Card(
    margin: EdgeInsets.symmetric(horizontal: 10),
    child: Padding(
      padding: const EdgeInsets.all(12.0),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            'About',style: TextStyle(fontSize: 20,fontWeight: FontWeight.bold,color: Colors.amber),),
          SizedBox(height: 10,),
          Text(user.about,style: TextStyle(fontSize: 16,height: 1.4),),
        ],
      ),
    ),
  );
  Widget WhatsApp(UserData user) => Card(
    margin: EdgeInsets.symmetric(horizontal: 10),
    child: Padding(
      padding: const EdgeInsets.all(12.0),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            'WhatsApp Number',style: TextStyle(fontSize: 20,fontWeight: FontWeight.bold,color: Colors.amber),),
          SizedBox(height: 10,),
          Text(user.whatsapp,style: TextStyle(fontSize: 16,height: 1.4),),
        ],
      ),
    ),
  );
  Widget buildCompany(UserData user) => Card(
    margin: EdgeInsets.symmetric(horizontal: 10),
    child: Padding(
      padding: const EdgeInsets.all(12.0),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            'Company',style: TextStyle(fontSize: 20,fontWeight: FontWeight.bold,color: Colors.amber),),
          SizedBox(height: 10,),
          Text(user.company,style: TextStyle(fontSize: 16,height: 1.4),),
        ],
      ),
    ),
  );

  Widget buildContry(UserData user) => Card(
    margin: EdgeInsets.symmetric(horizontal: 10),
    child: Padding(
      padding: const EdgeInsets.all(12.0),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            'Country',style: TextStyle(fontSize: 20,fontWeight: FontWeight.bold,color: Colors.amber),),
          SizedBox(height: 10,),
          Text(user.country,style: TextStyle(fontSize: 16,height: 1.4),),
        ],
      ),
    ),
  );

  Widget buildState(UserData user) => Card(
    margin: EdgeInsets.symmetric(horizontal: 10),
    child: Padding(
      padding: const EdgeInsets.all(12.0),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            'State',style: TextStyle(fontSize: 20,fontWeight: FontWeight.bold,color: Colors.amber),),
          SizedBox(height: 10,),
          Text(user.state,style: TextStyle(fontSize: 16,height: 1.4),),
        ],
      ),
    ),
  );


  Widget buildCity(UserData user) => Card(
    margin: EdgeInsets.symmetric(horizontal: 10),
    child: Padding(
      padding: const EdgeInsets.all(12.0),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            'City',style: TextStyle(fontSize: 20,fontWeight: FontWeight.bold,color: Colors.amber),),
          SizedBox(height: 10,),
          Text(user.city,style: TextStyle(fontSize: 16,height: 1.4),),
        ],
      ),
    ),
  );


  Widget buildpinCode(UserData user) => Card(
    margin: EdgeInsets.all(10),
    child: Padding(
      padding: const EdgeInsets.all(12.0),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            'PinCode',style: TextStyle(fontSize: 20,fontWeight: FontWeight.bold,color: Colors.amber),),
          SizedBox(height: 10,),
          Text(user.pincode,style: TextStyle(fontSize: 16,height: 1.4),),
        ],
      ),
    ),
  );

}
