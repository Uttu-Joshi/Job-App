import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:http/http.dart';
import 'package:job/Dashboard.dart';

class TextFieldWidget extends StatefulWidget {
  final int maxLines;
  final String label;
  final String text;
  final ValueChanged<String> onChanged;
  const TextFieldWidget({Key? key,
      this.maxLines = 1, required this.label, required this.text, required this.onChanged
  }) : super(key: key);

  @override
  State<TextFieldWidget> createState() => _TextFieldWidgetState();
}


class _TextFieldWidgetState extends State<TextFieldWidget> {
  late final TextEditingController controller;

  String msg = '';
  String txt = 'register';

  void EnterDetails(String controller) async {
    try{
      Response response = await post(
          Uri.parse('https://ewiz.gq/android/vendor_registration.php'),
          body: {
            'register':txt,
            'email' : controller,
            'mobile':controller,
            'name': controller,
            'vendor_type':controller,
            'city': controller,
            'country':controller,
            'state': controller,
            'whatsapp': controller,
          }
      );
      if(response.statusCode == 200){
        var userdata = jsonDecode(response.body.toString());
        if(userdata.length == 0){
          setState(() {
            msg = userdata["KEY_NOT_SET"];
          });
        }else {

          Navigator.push(
              context, MaterialPageRoute(builder: (context) => DashBoard()));
        }
      }
    }catch(e){
      print(e.toString());
    }
  }

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    controller = TextEditingController(text: widget.text);
  }

  @override
  void dispose() {
    // TODO: implement dispose
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(widget.label, style: TextStyle(fontWeight: FontWeight.bold,fontSize: 15,color: Colors.black),),
        SizedBox(height: 8,),
        TextField(
          controller: controller,
          maxLines: widget.maxLines,
          onChanged: widget.onChanged,
          decoration: InputDecoration(
            border: OutlineInputBorder(
              borderRadius: BorderRadius.circular(12),
            ),
          ),
        ),

      ],
    );
  }
}
