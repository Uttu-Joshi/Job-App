import 'dart:collection';
import 'dart:convert';

import 'ProfileData.dart';
import 'package:shared_preferences/shared_preferences.dart';

class UserPreferences{
  static late SharedPreferences? _preferences;

  static const _keyUser = 'user';
  static const myUser = UserData(
    imagePath: 'images/cat.jpg',
    name: 'The Desert Cactus',
    email: 'cactusjuiceDesert@gmail.com',
    about: 'A cactus is a member of the plant family Cactaceae, a family comprising about 127 genera with some 1750 known species of the order Caryophyllales.',
    isDarkMode: true,
    country: 'India',
    city: 'Potato Chips',
    pincode: '462016',
    whatsapp: '9826267587', state: 'NoWhere State',company: 'CCBul'
  );

  static Future init() async => _preferences = await SharedPreferences.getInstance();

  static Future setUSer(UserData user) async{
    final json = jsonEncode(user.toJson());
    await _preferences?.setString(_keyUser, json);
  }

  static UserData getUser() {
    final json = _preferences?.getString(_keyUser);
    return json == null ? myUser : UserData.fromJson(jsonDecode(json));
  }

}