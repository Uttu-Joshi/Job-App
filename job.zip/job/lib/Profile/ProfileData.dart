import 'package:flutter/cupertino.dart';

class UserData{
 final String imagePath;
   final String name;
   final String email;
  final String about;
  final String whatsapp;
  final String country;
  final String state;
  final String city;
  final String pincode;
  final String company;
  final bool isDarkMode;

  const UserData({
    required this.whatsapp, required this.country, required this.state, required this.city, required this.pincode, required this.company,
   required this.imagePath, required this.name,
    required this.email, required this.about, required this.isDarkMode,
});

  UserData copy({
   String? imagePath,
   String? name,
   String? email,
   String? about,
   String? whatsapp,
   String? country,
   String? state,
   String? city,
   String? pincode,
   String? company,
   bool? isDarkMode,

}) => UserData(
    imagePath: imagePath ?? this.imagePath,
    name: name ?? this.name,
    email: email ?? this.email,
    about: about ?? this.about,
    whatsapp: whatsapp ?? this.whatsapp,
    country: country ?? this.country,
    state: state ?? this.state,
    pincode: pincode ?? this.pincode,
    company: company ?? this.company,
    city: city ?? this.city,
    isDarkMode: isDarkMode ?? this.isDarkMode,
  );


 Map<String, dynamic> toJson() => {
   'imagePath': imagePath,
    'name':name,
   'email': email,
   'about':about,
   'whatsapp':whatsapp,
   'country':country,
   'state':state,
   'city': city,
   'pincode': pincode,
   'company': company,
   'isDarkMode': isDarkMode,
 };

 static UserData fromJson(Map<String,dynamic> json) => UserData(whatsapp:  json['whatsapp'],
     country: json['country'],
     state: json['state'],
     city: json['city'],
     pincode: json['pincode'],
     company: json['company'],
     imagePath: json['imagePath'],
     name: json['name'],
     email: json['email'],
     about: json['about'],
     isDarkMode: json['isDarkMode'],
 );

}