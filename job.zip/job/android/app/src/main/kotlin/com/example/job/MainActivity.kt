package com.example.job

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
